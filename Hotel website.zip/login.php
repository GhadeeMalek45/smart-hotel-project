<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "guests"; 


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $roomCode = $_POST['room-code'];
    $name = $_POST['name'];
    $phoneNumber = $_POST['phone-number'];


    if (empty($roomCode) || empty($name) || empty($phoneNumber)) {
        echo "Please fill out all fields!";
    } else {
   
        if (!preg_match("/^[0-9]{10}$/", $phoneNumber)) {
            echo "Please enter a valid 10-digit phone number.";
        } else {
      
            $sql = "SELECT * FROM infog WHERE NR = '$roomCode' AND PN = '$phoneNumber' AND Name = '$name'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
          
                echo "<script>alert('Logged in successfully!');</script>";
                echo "<script>window.location.href = 'menue page.html';</script>";
            } else {
              
                echo "<script>alert('No records found! Please register as a new user.');</script>";
                echo "<script>window.location.href = 'ex.html';</script>";
            }
        }
    }
}

$conn->close();
?>
