<form id="myForm" action="first_php.php" onsubmit="return myFunction();">
  First name: <input type="text" name="fname" id="fname"><br>
  Last name: <input type="text" name="lname" id="lname"><br><br>
  <input type="submit" value="Submit form">
</form>

<script>
  function myFunction() {
    if (document.getElementById("fname").value != "" && document.getElementById("lname").value != "") {
      return true; // Form is valid
    } else {
      alert("Please fill in both first name and last name."); // Display an error message to the user
      return false; // Prevent form submission
    }
  }
</script>