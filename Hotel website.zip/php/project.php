<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "guests"; 


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
    $room_code = $_POST['NR'];
    $name = $_POST['Name'];
    $phone_number = $_POST['PN'];

  
    $sql = "INSERT INTO infog (NR, Name, PN) 
            VALUES ('$room_code', '$name', '$phone_number')";

 
    if ($conn->query($sql) === TRUE) {
       
        echo "<script>
            alert('New user added successfully  " . htmlspecialchars($name) . "');
   
            window.location.href = 'wep project.html';
           
        </script>";
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();

?>

