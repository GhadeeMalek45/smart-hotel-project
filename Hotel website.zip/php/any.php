<?php

$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "guests"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$room_number = null; 
$name = $phone = $room = "";
$update_success = false; // Flag to check if update was successful

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fetch_data'])) {
    $room_number = trim($_POST['room_number']);

    if (!empty($room_number)) {
        $sql = "SELECT Name, PN, NR FROM infog WHERE NR = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $room_number);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $name = $row['Name'];
            $phone = $row['PN'];
            $room = $row['NR'];
        } else {
            echo "No data found for the given room number.";
        }
    } else {
        echo "Please enter a room number.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_data'])) {
    $room_number = trim($_POST['room']);
    $updated_name = trim($_POST['name']);
    $updated_phone = trim($_POST['phone']);

    if (!empty($room_number) && !empty($updated_name) && !empty($updated_phone)) {
        $update_sql = "UPDATE infog SET Name = ?, PN = ? WHERE NR = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("sss", $updated_name, $updated_phone, $room_number);

        if ($update_stmt->execute()) {
            $update_success = true; // Set to true when the update is successful
            $name = $updated_name;
            $phone = $updated_phone;
        } else {
            echo "Error updating data: " . $conn->error;
        }
    } else {
        echo "Please fill in all fields.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Update</title>
    <style>
       body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url('hotel.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }

        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.6); 
        }

        .container {
            position: relative;
            z-index: 2;
            background-color: rgba(255, 255, 255, 0.8); 
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.3);
            text-align: left;
            max-width: 400px;
            width: 100%;
        }

        h1 {
            color: rgba(50, 50, 50, 0.7);
            font-size: 36px;
            margin-bottom: 20px;
        }

        h2 {
            color: #555;
            margin-bottom: 30px;
            font-size: 24px;
        }

        .input-group {
            margin: 15px 0;
            display: flex;
            flex-direction: column;
        }

        .input-group label {
            font-size: 16px;
            color: #444;
        }

        input {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            padding: 10px 20px;
            background-color: #cdbf9d;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
        }

        button:hover {
            background-color: #303130;
        }

        .help {
            position: absolute;
            bottom: 20px;
            left: 20px;
        }

        .help a {
            color: #111111;
            font-size: 14px;
        }

        .help a:hover {
            color: blue;
        }

        .new-user {
            text-align: center;
            margin-top: 20px;
        }

        .new-user a {
            color: #111111;
            font-size: 14px;
        }

        .new-user a:hover {
            color: blue;
        }
    </style>
</head>
<body>

    <div class="overlay"></div>

    <div class="container">
        <h1>THE FIVE SEASONS HOTEL</h1>
        <h2>Fetch and Update User Data</h2>
        <form method="POST" action="">
            <div class="input-group">
                <label for="room_number">Enter Room Number</label>
                <input type="text" id="room_number" name="room_number" required>
            </div>
            <button type="submit" name="fetch_data">Fetch Data</button>
        </form>

        <?php if (!empty($room)): ?>
            <h1>Update User Data</h1>
            <form method="POST" action="">
                <div class="input-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
                </div>

                <div class="input-group">
                    <label for="phone">Phone</label>
                    <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($phone); ?>" required>
                </div>

                <div class="input-group">
                    <label for="room">Room</label>
                    <input type="text" id="room" name="room" value="<?php echo htmlspecialchars($room); ?>" readonly>
                </div>

                <button type="submit" name="update_data">Update</button>
            </form>
        <?php endif; ?>
    </div>

    <div class="help">
        <p><a href="contact.html">Need help? Contact us</a></p>
    </div>

    <?php if ($update_success): ?>
        <!-- Popup message on successful update -->
        <script>
            window.onload = function() {
                var confirmation = confirm("Data updated successfully! Click OK to proceed.");
                if (confirmation) {
                    window.location.href = "menue page.html"; // Redirect to menue page
                }
            }
        </script>
    <?php endif; ?>

</body>
</html>
