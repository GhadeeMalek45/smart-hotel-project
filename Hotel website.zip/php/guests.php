<?php


$host="localhost";
$username="root";
$password="";
$dbname="guests";

$conn = mysqli_connect('localhost', 'root', '', 'guests');

if ($conn) {
    echo "connected";
} else {
    die("no" . mysqli_connect_error()); 
}
?>